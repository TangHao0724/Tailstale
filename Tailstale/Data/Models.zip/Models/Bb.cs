﻿using System;
using System.Collections.Generic;

namespace Tailstale.Models;

public partial class Bb
{
    public int? CId { get; set; }

    public string? NameA { get; set; }

    public int? NameB { get; set; }
}
